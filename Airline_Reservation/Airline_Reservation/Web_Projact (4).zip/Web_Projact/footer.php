<footer>
	<div id="find">
	<h4>Contact Us</h4>
	<p>Emile:yourFlight111@gmail.com</p>
	<p>Call us:+966 50 000 0000</p>
	<img src="log/ins.png" class="icon">
	<img src="log/twi.png" class="icon">
	<img src="log/youtb.png" class="icon">
	<img src="log/fac.png" class="icon">
	<img src="log/google.png" class="icon">
	</div>
</footer>
</body>
</html>