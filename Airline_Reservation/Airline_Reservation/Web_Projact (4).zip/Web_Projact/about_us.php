<?php $title="About Us Page";
include("header.php") ;?>
 <!-- CONTENT HTML-->

 <content class="main-content">
                <div id="f-content">
                  <div id="p-text">
              <h1 id="p-title">Who Are We </h1>
              <p> Welcome to <strong> YOUR FLIGHT</strong> website </br><br>We are CS Students represent this website for the best travling experience.</br><br>
                We built this website to provide a satisfying services for the passengers from all around the world</br><br>
                 This website weill allow them to book their tickts, reserve hotels, and rent cars in a simplest way</br><br>
                   Read more about your trip below or contact us for more information.</p></div>
                   <div id = "m-content">
                     <span id="p-title">Project Member:</span>

                <div id="list">
                  <ul id="list-ul">
                    <li>Fatimah Al-johar  219010970</li></br>
                    <li>Latifah Aloseel   219008655</li></br>
                    <li>Dalia Al-gnam     219041499</li></br>
                    <li>Aishah Alafisan   219013453</li></br>
                    <li>Anfal Alshawaf    219012712</li>
                </div>
                   </div>
                   </div>






      </content>
      <script type="text/javascript" src="js/visible.js"></script>
      <!-- FOOTER HTML-->
      <?php include("footer.php")  ?>